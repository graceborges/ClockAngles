﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Revel.ClockAngles
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region attributes

        /// <summary>
        /// This will hold the string that the user enters
        /// </summary>
        string sTime;

        /// <summary>
        /// This will be the hour that was entered
        /// </summary>
        int iHourEntered;

        /// <summary>
        /// This will hold the minutes entered
        /// </summary>
        int iMinutesEntered;

        /// <summary>
        /// This is a new instance of the class clsTimeToAngles
        /// </summary>
        clsTimeToAngles clsNewTimeToAngles;

        #endregion

        public MainWindow()
        {
            InitializeComponent();

            //instantiating the new angle class
            clsNewTimeToAngles = new clsTimeToAngles();

        }

        #region methods

        /// <summary>
        /// When the user clicks the Get Angles button then we will pass the input into a method that
        /// will determine whether or not the input is valid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CmdSubmitTime_Click(object sender, RoutedEventArgs e)
        {
            //set sTime equal to the textbox entry
            sTime = tbxTime.Text;

            //send into method to check if it is valid
            IsValidTime(sTime);
        }

        /// <summary>
        /// This method will take in the single paramater sTime and then will break it up
        /// depending on how the user decided to enter the time. It could be entered either in
        /// form as 11 or 11:00. If it is entered without the ':' then we will just make sure it 
        /// is a number that was entered. If it was entered with the ':' then we will store it into
        /// an array and then determine from there if valid numbers were entered.
        /// After that is done we call the class function of determine angles and then will display 
        /// </summary>
        /// <param name="sTime">a string that the user themselves have entered</param>
        public void IsValidTime(string sTime)
        {
            //if the time is entered in the form {}:{}
            if (sTime.Contains(':'))
            {
                //create an array that will store the information split by the :
                string[] Time = sTime.Split(':');

                //tryparse the information to determine if the information entered are hours
                bool bHoursResult = Int32.TryParse(Time[0].ToString(), out iHourEntered);
                bool bMinutesResult = Int32.TryParse(Time[1].ToString(), out iMinutesEntered);

                //when both are valid numbers
                if (bHoursResult && bMinutesResult)
                {
                    //determine if it's a valid number for time, then send it to determine the angle and display
                    if ((iHourEntered >= 1 && iHourEntered <= 12) && (iMinutesEntered >= 0 && iMinutesEntered <= 59))
                    {
                        clsNewTimeToAngles.DetermineAngles(iHourEntered, iMinutesEntered);
                        tblkDisplayAngles.Text += "\nHour: " + iHourEntered + "\tMinutes: " + iMinutesEntered + "\tAngle: " + clsNewTimeToAngles.dAngle.ToString() + "°";
                    }
                    //not valid number then ask for a valid time
                    else
                    {
                        lblError.Content = "Please enter a valid time";
                    }
                }
                //not numbers then ask for a valid time
                else
                {
                    lblError.Content = "Please enter a valid time";
                }

            }
            //user entered the information in the form {}
            else
            {
                //tryparse the time entered to make sure it is an actual number
                bool bTimeResult = Int32.TryParse(sTime, out iHourEntered);

                //when it is a valid number
                if (bTimeResult)
                {
                    //determine if it is a valid number for hours and then set the minutes to 0, then determine the angle and display
                    if (iHourEntered >= 1 && iHourEntered <= 12)
                    {
                        iMinutesEntered = 00;
                        clsNewTimeToAngles.DetermineAngles(iHourEntered, iMinutesEntered);
                        tblkDisplayAngles.Text += "\nHour: " + iHourEntered + " Minutes: " + iMinutesEntered + " Angle: " + clsNewTimeToAngles.dAngle.ToString() + "°";
                    }
                }
                //not a valid number
                else
                {
                    lblError.Content = "Please enter a valid time";
                }
            }
        }

        #endregion
    }
}
