# ClockAngles

This program will take in a time in either the format of 11 or 11:00. If not then an error will be displayed.From there it will convert the time over to the angle that it will be.
