﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Revel.ClockAngles
{
    class clsTimeToAngles
    {

        #region attributes
        /// <summary>
        /// This will hold the double value for the angle
        /// </summary>
        public double dAngle;

        /// <summary>
        /// This will hold the hour passed in
        /// </summary>
        int iHour;

        /// <summary>
        /// This will hold the minutes passed in
        /// </summary>
        int iMinutes;

        #endregion

        #region methods

        /// <summary>
        /// This will determine the angle based on the math equation |0.5 * (60 * iHour)-(11 * iMinutes)|
        /// which is the equation to figure out the angle between the hour and minutes hand. Two ints will
        /// need to be passed in so that the equation can be filled out properly
        /// </summary>
        /// <param name="iHourEntered">an int between 1 and 12</param>
        /// <param name="iMinutesEntered">an int between 0 and 59 </param>
        public void DetermineAngles(int iHourEntered, int iMinutesEntered)
        {
            //set the values of hour and minutes to what was passed in
            iHour = iHourEntered;
            iMinutes = iMinutesEntered;

            //determine the angle based on the equation and then find the absolute value of it
            dAngle = (0.5 * ((60 * iHour)-(11 * iMinutes)));
            dAngle = Math.Abs(dAngle);

            //if the angle is greater than 180, you need to subtract it from 360
            if(dAngle > 180)
            {
                dAngle = 360 - dAngle;
            }

        }

        #endregion
    }
}
